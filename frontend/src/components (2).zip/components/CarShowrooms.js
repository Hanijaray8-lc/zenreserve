import React, { useState, useEffect } from 'react';
import {
  Box, Typography, TextField, MenuItem, Grid, Button, InputAdornment, CircularProgress,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import SearchIcon from '@mui/icons-material/Search';
import PaidOutlinedIcon from '@mui/icons-material/PaidOutlined';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';

const CarShowrooms = () => {
  const [data, setData] = useState([]);
  const [search, setSearch] = useState('');
  const [area, setArea] = useState('All Areas');
  const [loading, setLoading] = useState(true);

  const [city, setCity] = useState('');
  const [district, setDistrict] = useState('');
  const [category, setCategory] = useState('');

  const navigate = useNavigate();
  const location = useLocation();

  // Fetch data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/business/carshowrooms');
        setData(res.data);
      } catch (err) {
        console.error("Error fetching car showrooms:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // Parse URL params
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const cityParam = params.get('city');
    const districtParam = params.get('district');
    const categoryParam = params.get('category');

    if (cityParam) {
      setCity(cityParam);
      setArea(cityParam); // default filter area to city param
    }
    if (districtParam) setDistrict(districtParam);
    if (categoryParam) setCategory(categoryParam);
  }, [location.search]);

  const uniqueAreas = ['All Areas', ...new Set(data.map(d => d.areaName))];

  const filteredData = data.filter(d =>
    (area === 'All Areas' || d.areaName === area || d.city === area) &&
    (!city || d.city === city) &&
    (!district || d.district === district) &&
    (!category || d.category === category || d.listingType === 'Car Showroom') &&
    d.orgName?.toLowerCase().includes(search.toLowerCase())
  );

  const handleCardClick = (item) => {
    navigate('/car-login', { state: { carShowroom: item } });
  };

  const handleGoBack = () => navigate(-1);

  return (
    <Box sx={{ background: 'linear-gradient(135deg, #f0f8ff, #ffffff)', minHeight: '100vh', pb: 6 }}>
      {/* Header */}
      <Box sx={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        mb: 3, p: 2, backgroundColor: 'rgba(255, 255, 255, 0.9)',
        flexDirection: { xs: 'column', sm: 'row' }, gap: 2
      }}>
        <Button
          variant="contained"
          startIcon={<ArrowBackIcon />}
          onClick={handleGoBack}
          sx={{
            minWidth: { xs: '100%', sm: 'auto' },
            bgcolor: '#3f51b5',
            '&:hover': { bgcolor: '#5c6bc0' }
          }}
        >
          Go Back
        </Button>
        <Typography variant="h4" fontWeight="bold" textAlign="center" sx={{
          color: '#3f51b5', flexGrow: 1, mr: { xs: 0, sm: 2 }
        }}>
          All Car Showrooms in {city || 'Your Location'}
        </Typography>
      </Box>

      {/* Filters */}
      <Grid container spacing={2} justifyContent="center" alignItems="center" sx={{
        mb: 5, px: 2, py: 2, backgroundColor: 'rgba(255, 255, 255, 0.9)'
      }}>
        <Grid item>
          <TextField
            select
            label="Area"
            value={area}
            onChange={(e) => setArea(e.target.value)}
            variant="outlined"
            size="small"
            InputLabelProps={{ shrink: true }}
            sx={{
              width: 250, backgroundColor: '#fff', borderRadius: 1,
              '& .MuiInputBase-root': { height: 45 }
            }}
          >
            {uniqueAreas.map((areaOption, i) => (
              <MenuItem key={i} value={areaOption}>{areaOption}</MenuItem>
            ))}
          </TextField>
        </Grid>

        <Grid item>
          <TextField
            placeholder="Search by Showroom Name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            variant="outlined"
            size="small"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: 'action.active' }} />
                </InputAdornment>
              ),
              style: { height: 45 }
            }}
            sx={{ width: 250, backgroundColor: '#fff', borderRadius: 1 }}
          />
        </Grid>
      </Grid>

      {/* Loading */}
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 10 }}>
          <CircularProgress />
        </Box>
      ) : (
        /* Showroom Cards */
        <Box sx={{ px: 2, pb: 4 }}>
          <Grid container spacing={3} justifyContent="center">
            {filteredData.length === 0 ? (
              <Typography variant="h6" sx={{ mt: 4 }}>
                No showrooms found for selected filters.
              </Typography>
            ) : (
              filteredData.map((d) => (
                <Grid item key={d._id}>
                  <Box
                    onClick={() => handleCardClick(d)}
                    sx={{
                      position: 'relative',
                      display: 'flex',
                      flexDirection: 'row',
                      alignItems: 'flex-start',
                      gap: 2,
                      p: 2,
                      width: 380,
                      height: 120,
                      backgroundColor: '#fff',
                      borderLeft: '8px solid #1976d2',
                      borderRadius: '8px',
                      boxShadow: 2,
                      cursor: 'pointer',
                      transition: '0.3s',
                      '&:hover': {
                        boxShadow: 6,
                        backgroundColor: '#f0f0f0',
                        transform: 'scale(1.02)',
                      },
                    }}
                  >
                    <Box
                      component="img"
                      src={`http://localhost:5000/uploads/${d.profileImage}`}
                      alt={d.orgName}
                      sx={{ width: 100, height: 100, objectFit: 'cover', borderRadius: 2 }}
                    />
                    <Box sx={{ flexGrow: 1, overflow: 'hidden' }}>
                      <Typography variant="h6" fontWeight="bold" noWrap>{d.orgName}</Typography>
                      <Box display="flex" alignItems="center" gap={1} mb={0.5}>
                        <AccessTimeIcon fontSize="small" sx={{ color: 'text.secondary' }} />
                        <Typography variant="body2" color="text.secondary" noWrap>
                          {d.openingTime} - {d.closingTime}
                        </Typography>
                      </Box>
                      <Box display="flex" alignItems="center" gap={1} mb={0.5}>
                        <LocationOnIcon fontSize="small" sx={{ color: 'text.secondary' }} />
                        <Typography variant="body2" color="text.secondary" noWrap>
                          {d.city} ({d.areaName})
                        </Typography>
                      </Box>
                      <Box display="flex" alignItems="center" gap={1}>
                        <PaidOutlinedIcon fontSize="small" color="success" />
                        <Typography variant="caption" color="success.main" noWrap>
                          EMI / Pay Offline Available
                        </Typography>
                      </Box>
                    </Box>
                  </Box>
                </Grid>
              ))
            )}
          </Grid>
        </Box>
      )}
    </Box>
  );
};

export default CarShowrooms;
{/*import React, { useState, useEffect } from 'react';
import {
  Box, Typography, TextField, MenuItem, Grid, Button, InputAdornment,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import SearchIcon from '@mui/icons-material/Search';
import PaidOutlinedIcon from '@mui/icons-material/PaidOutlined';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';

const CarShowrooms = () => {
  const [data, setData] = useState([]);
  const [search, setSearch] = useState('');
  const [area, setArea] = useState('All Areas');
  const [loading, setLoading] = useState(true);

  const [city, setCity] = useState('');
  const [district, setDistrict] = useState('');
  const [category, setCategory] = useState('');

  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/business/carshowrooms'); // ✅ Make sure this route exists
        setData(res.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const cityParam = params.get('city');
    const districtParam = params.get('district');
    const categoryParam = params.get('category');

    if (cityParam) setCity(cityParam);
    if (districtParam) setDistrict(districtParam);
    if (categoryParam) setCategory(categoryParam);
    if (cityParam) setArea(cityParam);
  }, [location.search]);

  const uniqueAreas = ['All Areas', ...new Set(data.map(d => d.areaName))];

  const filteredData = data.filter(d =>
    (area === 'All Areas' || d.areaName === area || d.city === area) &&
    (!city || d.city === city) &&
    (!district || d.district === district) &&
    (!category || d.category === category || d.listingType === 'Car Showroom') &&
    d.orgName?.toLowerCase().includes(search.toLowerCase())
  );

  const handleCardClick = (item) => {
    navigate('/car-login', { state: { carShowroom: item } });
  };

  const handleGoBack = () => navigate(-1);

  return (
    <Box sx={{ background: 'linear-gradient(135deg, #f0f8ff, #ffffff)', minHeight: '100vh', pb: 6 }}>
      <Box sx={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        mb: 3, p: 2, backgroundColor: 'rgba(255, 255, 255, 0.9)',
        flexDirection: { xs: 'column', sm: 'row' }, gap: 2
      }}>
        <Button
          variant="contained"
          startIcon={<ArrowBackIcon />}
          onClick={handleGoBack}
          sx={{
            minWidth: { xs: '100%', sm: 'auto' },
            bgcolor: '#3f51b5',
            '&:hover': { bgcolor: '#5c6bc0' }
          }}
        >
          Go Back
        </Button>
        <Typography variant="h4" fontWeight="bold" textAlign="center" sx={{
          color: '#3f51b5', flexGrow: 1, mr: { xs: 0, sm: 2 }
        }}>
          All Car Showrooms in Tirunelveli
        </Typography>
      </Box>

      <Grid container spacing={2} justifyContent="center" alignItems="center" sx={{
        mb: 5, px: 2, py: 2, backgroundColor: 'rgba(255, 255, 255, 0.9)'
      }}>
        <Grid item>
          <TextField
            select
            label="Area"
            value={area}
            onChange={(e) => setArea(e.target.value)}
            variant="outlined"
            size="small"
            InputLabelProps={{ shrink: true }}
            sx={{
              width: 250, backgroundColor: '#fff', borderRadius: 1,
              '& .MuiInputBase-root': { height: 45 }
            }}
          >
            {uniqueAreas.map((areaOption, i) => (
              <MenuItem key={i} value={areaOption}>{areaOption}</MenuItem>
            ))}
          </TextField>
        </Grid>

        <Grid item>
          <TextField
            placeholder="Search by Showroom Name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            variant="outlined"
            size="small"
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: 'action.active' }} />
                </InputAdornment>
              ),
              style: { height: 45 }
            }}
            sx={{ width: 250, backgroundColor: '#fff', borderRadius: 1 }}
          />
        </Grid>
      </Grid>

      <Box sx={{ px: 2, pb: 4 }}>
        <Grid container spacing={3} justifyContent="center">
          {filteredData.map((d) => (
            <Grid item key={d._id}>
              <Box
                onClick={() => handleCardClick(d)}
               sx={{
                  position: 'relative',
                  display: 'flex',
                  flexDirection: 'row',
                  alignItems: 'flex-start',
                  gap: 2,
                  p: 2,
                  width: 420,
                  height: 120,
                  backgroundColor: '#fff',
                  borderLeft: '8px solid #1976d2',
                  borderRadius: '8px',
                  boxShadow: 2,
                  cursor: 'pointer',
                  transition: '0.3s',
                  '&:hover': {
                    boxShadow: 6,
                    backgroundColor: '#f0f0f0',
                    transform: 'scale(1.02)',
                  },
                }}
              >
                <Box
                  component="img"
                  src={`http://localhost:5000/uploads/${d.profileImage}`}
                  alt={d.orgName}
                  sx={{ width: 100, height: 100, objectFit: 'cover', borderRadius: 2 }}
                />
                <Box sx={{ flexGrow: 1, overflow: 'hidden' }}>
                  <Typography variant="h6" fontWeight="bold" noWrap>{d.orgName}</Typography>
                  <Box display="flex" alignItems="center" gap={1} mb={0.5}>
                    <AccessTimeIcon fontSize="small" sx={{ color: 'text.secondary' }} />
                    <Typography variant="body2" color="text.secondary" noWrap>
                      {d.openingTime} - {d.closingTime}
                    </Typography>
                  </Box>
                  <Box display="flex" alignItems="center" gap={1} mb={0.5}>
                    <LocationOnIcon fontSize="small" sx={{ color: 'text.secondary' }} />
                    <Typography variant="body2" color="text.secondary" noWrap>
                      {d.city} ({d.areaName})
                    </Typography>
                  </Box>
                  <Box display="flex" alignItems="center" gap={1}>
                    <PaidOutlinedIcon fontSize="small" color="success" />
                    <Typography variant="caption" color="success.main" noWrap>
                      EMI / Pay Offline Available
                    </Typography>
                  </Box>
                </Box>
              </Box>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Box>
  );
};

export default CarShowrooms;*/}
