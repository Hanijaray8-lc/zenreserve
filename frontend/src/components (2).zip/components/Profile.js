import React, { useEffect, useState } from 'react';
import {
  Box,
  Card,
  Typography,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
} from '@mui/material';

import LogoutIcon from '@mui/icons-material/Logout';
import DeleteIcon from '@mui/icons-material/Delete';
import LocalOfferIcon from '@mui/icons-material/LocalOffer';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import { useNavigate } from 'react-router-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';


const Profile = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [logoutOpen, setLogoutOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('user');
    if (stored) {
      const parsed = JSON.parse(stored);
      setUser(parsed);
    } else {
      navigate('/login'); // Redirect if not logged in
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('user');
    setLogoutOpen(false);
    navigate('/login');
  };

  const handleDeleteAccount = () => {
    localStorage.removeItem('user'); // Or send delete request to backend
    setDeleteOpen(false);
    navigate('/login');
  };

  const cardStyle = {
    width: 290,
    p: 4,
    textAlign: 'center',
    boxShadow: 5,
    bgcolor: '#c06bff',
    '&:hover': { backgroundColor: '#dca7e4' },
    cursor: 'pointer',
    borderRadius: 5,
  };

  return (
    
    <Box
      sx={{
        position: 'relative',
        minHeight: '100vh',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden',
        px: 3,
        '&::-webkit-scrollbar': { display: 'none' },
        scrollbarWidth: 'none',
      }}
    >
        <Button
    variant="text"
    startIcon={<ArrowBackIcon />}
    onClick={() => navigate(-1)}
    sx={{
      position: 'absolute',
      top: 16,
      left: 16,
      zIndex: 3,
      color: '#6a1b9a',
      fontWeight: 'bold',
      textTransform: 'none',
    }}
  >
    Back
  </Button>
      <Box
        sx={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          backgroundImage: `url("/icons.png")`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          opacity: 0.16,
          zIndex: 0,
        }}
      />

      <Box
        sx={{
          position: 'relative',
          zIndex: 2,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          maxWidth: 1200,
          width: '100%',
          py: 5,
        }}
      >
        <Box
          sx={{
            width: 300,
            height: 100,
            borderRadius: 3,
            backgroundColor: '#edb1f2',
            display: 'flex',
            alignItems: 'center',
            px: 2,
            boxShadow: 10,
            mb: 12,
          }}
        >
          <Box
            sx={{
              width: 55,
              height: 55,
              borderRadius: '50%',
              overflow: 'hidden',
              border: '2px solid white',
              mr: 2,
            }}
          >
            <img
              src="/icons.png"
              alt="Profile"
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
          </Box>

          <Box>
            <Typography variant="subtitle2" fontWeight="bold" color="white">
              {user?.name}
            </Typography>
            <Typography variant="caption" color="white">
              {user?.phone}
            </Typography>
          </Box>
        </Box>

        <Box
          sx={{
            display: 'flex',
            justifyContent: 'center',
            gap: 3,
            flexWrap: 'nowrap',
            overflowX: 'auto',
            width: '100%',
            maxWidth: 1100,
            '&::-webkit-scrollbar': { display: 'none' },
            scrollbarWidth: 'none',
          }}
        >
          <Card onClick={() => navigate('/my-bookings')} sx={cardStyle}>
            <CalendarTodayIcon sx={{ fontSize: 32, color: '#1976d2' }} />
            <Typography sx={{ mt: 1 }}>My Bookings</Typography>
          </Card>
          <Card onClick={() => navigate('/my-offers')} sx={cardStyle}>
            <LocalOfferIcon sx={{ fontSize: 32, color: '#9c27b0' }} />
            <Typography sx={{ mt: 1 }}>My Offers</Typography>
          </Card>
          <Card onClick={() => setLogoutOpen(true)} sx={cardStyle}>
            <LogoutIcon sx={{ fontSize: 32, color: '#0288d1' }} />
            <Typography sx={{ mt: 1 }}>Logout</Typography>
          </Card>
          <Card onClick={() => setDeleteOpen(true)} sx={cardStyle}>
            <DeleteIcon sx={{ fontSize: 32, color: '#d32f2f' }} />
            <Typography sx={{ mt: 1 }}>Delete Account</Typography>
          </Card>
        </Box>
      </Box>

      <Dialog open={logoutOpen} onClose={() => setLogoutOpen(false)}>
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
          <ExitToAppIcon sx={{ fontSize: 40, color: '#e53935' }} />
        </Box>
        <DialogTitle textAlign="center">Are you sure you want to logout?</DialogTitle>
        <DialogContent sx={{ textAlign: 'center' }}>
          You will be returned to the login screen.
        </DialogContent>
        <DialogActions sx={{ justifyContent: 'center', pb: 2 }}>
          <Button variant="outlined" onClick={handleLogout}>Logout</Button>
          <Button variant="outlined" onClick={() => setLogoutOpen(false)}>Cancel</Button>
        </DialogActions>
      </Dialog>

      <Dialog open={deleteOpen} onClose={() => setDeleteOpen(false)}>
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
          <WarningAmberIcon sx={{ fontSize: 40, color: 'red' }} />
        </Box>
        <DialogTitle textAlign="center">Are you sure you want to delete your account?</DialogTitle>
        <DialogContent sx={{ textAlign: 'center' }}>
          This action is irreversible, and all your data will be lost.
        </DialogContent>
        <DialogActions sx={{ justifyContent: 'center', pb: 2 }}>
          <Button variant="outlined" onClick={handleDeleteAccount}>Delete</Button>
          <Button variant="outlined" onClick={() => setDeleteOpen(false)}>Cancel</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default Profile;
