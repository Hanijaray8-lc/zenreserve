import React, { useState } from 'react';
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  Box
} from '@mui/material';

function PopupForm({ open, onClose, onSignup }) {
  const [mobile, setMobile] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = () => {
    // ✅ Basic validation
    if (!mobile || !name || !password) {
      alert("Please fill all fields.");
      return;
    }
    if (password.length !== 4) {
      alert("Password must be 4 digits.");
      return;
    }

    // ✅ Call parent signup handler with data
    if (onSignup && typeof onSignup === 'function') {
      onSignup({ mobile, name, password });
    }

    // Optional: clear form after submit
    setMobile('');
    setName('');
    setPassword('');
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle
        sx={{
          bgcolor: '#ce99ca',
          color: 'white',
          textAlign: 'center'
        }}
      >
        GoZlot
      </DialogTitle>
      <DialogContent sx={{ bgcolor: '#ce99ca' }}>
        <Box sx={{ mt: 2 }}>
          <TextField
            fullWidth
            label="Mobile No *"
            placeholder="Enter your mobile number"
            variant="outlined"
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            sx={{ mb: 2, backgroundColor: 'white', borderRadius: 1 }}
          />
          <TextField
            fullWidth
            label="Name *"
            placeholder="Enter your name"
            variant="outlined"
            value={name}
            onChange={(e) => setName(e.target.value)}
            sx={{ mb: 2, backgroundColor: 'white', borderRadius: 1 }}
          />
          <TextField
            fullWidth
            label="Set 4 Digit Password *"
            placeholder="Set 4 digit password"
            variant="outlined"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            sx={{ mb: 2, backgroundColor: 'white', borderRadius: 1 }}
          />

          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 2 }}>
            <Button variant="outlined" onClick={onClose}>Cancel</Button>
            <Button
              variant="contained"
              sx={{
                backgroundColor: '#4b0082',
                '&:hover': { backgroundColor: '#4b0082' }
              }}
              onClick={handleSubmit}
            >
              Sign Up
            </Button>
          </Box>
        </Box>
      </DialogContent>
    </Dialog>
  );
}

export default PopupForm;
