import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Select,
  MenuItem,
  IconButton,
  Grid,
  InputAdornment,
} from '@mui/material';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import ListAltIcon from '@mui/icons-material/ListAlt';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';

const EventSection = () => {
  const navigate = useNavigate();
  const containerRef = useRef(null);

  const [cities, setCities] = useState([]);
  const [listingTypes, setListingTypes] = useState([]);
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');

  const categories = [
    { src: 'hospitall.jpg',name: 'Hospital', path: '/hospitals' },
    {src: 'parlar.jpg', name: 'Parlours', path: '/pourlars' },
    {src: 'lab.png', name: 'Laboratories', path: '/laboratories' },
    { src: 'saloon.jpg',name: 'Salons', path: '/salons' },
    { src: 'drawing.jpg',name: 'Drawingclass', path: '/drawingclass' },
    { src: 'showroom.jpg',name: 'Car showroom', path: '/carshowroom' },
    { src: 'Electranics.jpg',name: 'Electronic Service', path: '/electronic' },
    { src: 'mechanicshop.png',name: 'Mechanic Shop', path: '/mechanic' },


  ];
  
  const [scrollIndex, setScrollIndex] = useState(0);

  const handleScroll = (direction) => {
    if (direction === 'left') {
      setScrollIndex((prevIndex) => (prevIndex - 3 < 0 ? 0 : prevIndex - 3));
    } else if (direction === 'right') {
      setScrollIndex((prevIndex) =>
        prevIndex + 3 >= categories.length ? prevIndex : prevIndex + 3
      );
    }
  };

  // 📝 Fetch cities and listingTypes on load
  useEffect(() => {
    const fetchData = async () => {
      try {
        const citiesRes = await axios.get('http://localhost:5000/api/business/cities');
        setCities(citiesRes.data);

        const typesRes = await axios.get('http://localhost:5000/api/business/listingTypes');
        setListingTypes(typesRes.data);
      } catch (err) {
        console.error('Error fetching cities or listingTypes:', err);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    const container = containerRef.current;
    if (container) {
      const scrollAmount = container.scrollWidth / Math.ceil(categories.length / 3);
      container.scrollTo({
        left: scrollIndex * scrollAmount,
        behavior: 'smooth',
      });
    }
  }, [scrollIndex, categories.length]);



  const handleCategorySelect = (category) => {
  setSelectedCategory(category);
  const selected = categories.find((c) => c.name === category);
  if (selected) {
    const cityParam = selectedCity ? `?city=${encodeURIComponent(selectedCity)}` : '';
    navigate(`${selected.path}${cityParam}`);
  }
};




  return (
    <>
      <Navbar />
      <Hero />

 <Box sx={{ p: 5 }}>
  {/* Upcoming Events */}
<Box sx={{ display: 'flex', gap: 4, mb: 4, flexWrap: 'wrap' }}>
  {/* Left: Filter Panel */}
  <Card
    sx={{
      width: '100%',
      maxWidth: 450,
      backgroundColor: '#ce99ca',
      borderRadius: 3,
      boxShadow: 4,
      p: 3,
    }}
  >
    <CardContent>
      <Typography variant="h6" fontWeight="bold" sx={{ color: 'white', mb: 2 }}>
        Filter Departments
      </Typography>

   
      <Select
        fullWidth
        variant="outlined"
        value={selectedCity}
        onChange={(e) => setSelectedCity(e.target.value)}
        displayEmpty
        sx={{
          mb: 3,
          backgroundColor: 'white',
          borderRadius: 1,
        }}
        startAdornment={
          <InputAdornment position="start">
            <LocationOnIcon />
          </InputAdornment>
        }
      >
        <MenuItem value="">Select City/District</MenuItem>
        {cities.map((city, index) => (
          <MenuItem key={index} value={city}>{city}</MenuItem>
        ))}
      </Select>

   
      <Select
        fullWidth
        variant="outlined"
        value={selectedCategory}
        onChange={(e) => handleCategorySelect(e.target.value)}
        displayEmpty
        sx={{ backgroundColor: 'white', borderRadius: 1 }}
        startAdornment={
          <InputAdornment position="start">
            <ListAltIcon />
          </InputAdornment>
        }
      >
        <MenuItem value="">Select Department</MenuItem>
        {listingTypes.map((type, index) => (
          <MenuItem key={index} value={type}>{type}</MenuItem>
        ))}
      </Select>
    </CardContent>
  </Card>

  {/* Right: Catchy Message */}
<Box
  sx={{
    flex: 1,
    backgroundColor: '#ce99ca', // Matching background
    borderRadius: 3,
    boxShadow: 4,               // Match left card's shadow
    p: 4,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 250,
  }}
>
  <Typography variant="h6" fontWeight="bold" sx={{ color: 'white', textAlign: 'center' }}>
    Discover & Book Local Services Instantly! <br />
    <span style={{ fontWeight: 400, fontSize: '1rem' }}>
      From <strong>Gyms</strong> to <strong>Salons</strong>, <strong>Hospitals</strong> to <strong>Drawing Classes</strong> — we've got your city covered!
    </span>
  </Typography>
</Box>

</Box>



  {/* Available Categories */}
  <Box>
    <Typography variant="h6" fontWeight="bold" mb={2}>
      Available departments
    </Typography>

    <Card
      sx={{
        width: '100%',
        backgroundColor: '#fff',
        boxShadow: 3,
        p: 2,
        borderRadius: 2,
      }}
    >
      <Grid container spacing={2}>
        {categories.map((category, index) => (
       <Grid item xs={12} sm={6} md={4} key={index} sx={{ display: 'flex', justifyContent: 'center' }}>
  <Box
    sx={{
      background: 'linear-gradient(135deg, #f5f7fa, #c3cfe2)',
      width: '100%',            // Ensures consistent sizing
      maxWidth: 330,            // Optional: limit card width
      minHeight: 260,           // Taller card for consistency
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 2,
      padding: 3,
      cursor: 'pointer',
      boxShadow: '0 4px 20px rgba(213, 28, 28, 0.1)',
      transition: 'transform 0.3s, box-shadow 0.3s',
      '&:hover': {
        transform: 'translateY(-5px)',
        boxShadow: '0 10px 25px rgba(180, 7, 7, 0.2)',
      },
    }}
    onClick={() => navigate(category.path)}
  >
    <img
      src={`/${category.src}`}
      alt={category.name}
      style={{
        width: 250,
        height: 150,
        objectFit: 'cover',
        borderRadius: 12,
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
      }}
    />
    <Typography
      variant="h6"
      fontWeight="bold"
      sx={{ mt: 2, textAlign: 'center', color: '#333' }}
    >
      {category.name}
    </Typography>
  </Box>
</Grid>

        ))}
      </Grid>
    </Card>
  </Box>
</Box>

    </>
  );
};

export default EventSection;
