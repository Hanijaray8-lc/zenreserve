import React from 'react';
import { Box, Typography, Button } from '@mui/material';
import { useNavigate } from 'react-router-dom';
//import NoBookingImage from '../assets/no-booking.png'; // ✅ Use your actual image path

const MyBookings = () => {
  const navigate = useNavigate();

  return (
    <Box
      sx={{
        p: 4,
        minHeight: '80vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
      }}
    >
      <Typography variant="h5" sx={{ fontWeight: 'bold', mb: 1 }}>
        Booking History
      </Typography>
      <Typography variant="subtitle1" sx={{ color: 'gray', mb: 4 }}>
        No Bookings Found
      </Typography>

     {/*  <Box
        component="img"
        src={NoBookingImage}
        alt="No Bookings"
        sx={{ maxWidth: 250, mb: 4 }}
      />*/}

      <Button
        variant="outlined"
        onClick={() => navigate('/')}
        sx={{
          borderRadius: '20px',
          textTransform: 'none',
          fontWeight: 'bold',
          borderColor: '#8bc34a',
          color: '#689f38',
          '&:hover': {
            backgroundColor: '#dcedc8',
            borderColor: '#689f38',
          },
        }}
      >
        New Booking
      </Button>
    </Box>
  );
};

export default MyBookings;
