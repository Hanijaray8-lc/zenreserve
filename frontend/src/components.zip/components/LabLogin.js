import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  MenuItem,
  Button,
  Checkbox,
  FormControlLabel,
  Chip,
  Grid,
} from '@mui/material';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import { motion } from 'framer-motion';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';

const LabLogin = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const lab = location.state?.lab;

  const [date, setDate] = useState('');
  const [particularName, setParticularName] = useState('');
  const [department, setDepartment] = useState('');
  const [timeSlot, setTimeSlot] = useState('');
  const [fillDetails, setFillDetails] = useState(false);
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');

  useEffect(() => {
    const today = new Date().toLocaleDateString('en-GB'); // Format: DD/MM/YYYY
    setDate(today);
  }, []);

  const handleSubmit = async () => {
    if (!lab?._id) {
      alert("Lab data is missing.");
      return;
    }

    const appointmentData = {
      date,
      particularName,
      department,
      name,
      mobile,
      hospitalId: lab._id,
         orgName: lab?.orgName,   
          serviceType: "lab", 
    };

    try {
      await axios.post('http://localhost:5000/api/appointments', appointmentData);
      alert('Appointment booked successfully!');
      navigate('/');
    } catch (error) {
      console.error('Error saving appointment:', error);
      alert('Failed to save appointment. Try again.');
    }
  };

  return (
    <Box sx={{ p: 4, backgroundColor: '#f9f9f9', minHeight: '100vh' }}>
      <Grid
        container
        spacing={3}
        sx={{
          maxWidth: 750,
          mx: 'auto',
          backgroundColor: 'rgb(98, 123, 159)',
          borderRadius: 3,
          p: 2,
          boxShadow: 3,
        }}
      >
        {/* Left Panel: Lab Info */}
        <Grid item xs={12} sm={6}>
          <motion.div
            initial={{ x: -80, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
          >
            <Card sx={{ backgroundColor: '#f0f0f0', borderRadius: 2 }}>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'center', mb: 8 }}>
                  <img
                        src="./lab2.jpg"
             
                    alt="Lab Announcement"
                    style={{
                      border: '2px solid black',
                      padding: 16,
                      borderRadius: 12,
                      backgroundColor: 'white',
                      maxWidth: '100%',
                      height: 160,
                    }}
                  />
                </Box>

                <Typography variant="h6" fontWeight="bold" gutterBottom>
                  Service Details
                </Typography>

                <Chip
                  label="Pay Offline"
                  size="small"
                  sx={{
                    backgroundColor: '#90ee90',
                    fontWeight: 'bold',
                    mb: 2,
                  }}
                />

                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <img
                          src={`http://localhost:5000/uploads/${lab?.profileImage || 'lab2.jpg'}`}
                    alt="Lab Logo"
                    style={{ width: 70, height: 70, borderRadius: 8 }}
                  />
                  <Box sx={{ ml: 2 }}>
                    <Typography variant="subtitle1" fontWeight="bold">
                      {lab?.orgName}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {lab?.areaName}, {lab?.city}
                    </Typography>
                  </Box>
                </Box>

                <Box sx={{ backgroundColor: '#d0f0c0', p: 1.5, borderRadius: 2 }}>
                  <Typography variant="body2" fontWeight="bold">
                    🛎️ Special announcement! Slots open from
                  </Typography>
                  <Typography variant="body2">
                    {lab?.openingTime} - {lab?.closingTime}
                  </Typography>
                </Box>
              </CardContent>
            </Card>
          </motion.div>
        </Grid>

        {/* Right Panel: Booking Form */}
        <Grid item xs={12} sm={6}>
          <motion.div
            initial={{ x: 80, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.6 }}
          >
            <Card sx={{ borderRadius: 2 }}>
              <CardContent>
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                         <TextField
                                 label="Choose Date"
                                 type="date"
                                 value={date}
                                 onChange={(e) => setDate(e.target.value)}
                                 fullWidth
                                 InputLabelProps={{ shrink: true }}
                                 sx={{ backgroundColor: 'white' }}
                               />

                  <TextField
                    label="Particular Name *"
                    value={particularName}
                    onChange={(e) => setParticularName(e.target.value)}
                    fullWidth
                    sx={{ backgroundColor: 'white' }}
                  />

                  <TextField
                    label="Departments *"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    fullWidth
                    sx={{ backgroundColor: 'white' }}
                  />

            

                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={fillDetails}
                        onChange={(e) => setFillDetails(e.target.checked)}
                      />
                    }
                    label="Fill my details (Name & Mobile)"
                  />

                  <TextField
                    label="Name *"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    fullWidth
                    sx={{ backgroundColor: 'white' }}
                  />

                        <TextField
                  label="Mobile Number *"
                  value={mobile}
                  onChange={(e) => {
                    const val = e.target.value;
                    if (/^\d{0,10}$/.test(val)) { // ✅ Allow only up to 10 digits
                      setMobile(val);
                    }
                  }}
                  fullWidth
                  sx={{ backgroundColor: 'white' }}
                />

                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 2 }}>
                    <Button variant="contained" sx={{ backgroundColor: '#4b0082' }} onClick={handleSubmit}>
                      Submit
                    </Button>
                   <Button variant="outlined" onClick={() => navigate(-1)}>Cancel</Button>
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </motion.div>
        </Grid>
      </Grid>
    </Box>
  );
};

export default LabLogin;
