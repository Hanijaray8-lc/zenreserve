import React, { useState, useEffect } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  MenuItem,
  Button,
  Checkbox,
  FormControlLabel,
  Chip,
  Grid,
} from '@mui/material';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import { motion } from 'framer-motion';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';

const DrawingLogin = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const drawing = location.state?.drawingClass;

  const [date, setDate] = useState('');
  const [particularName, setParticularName] = useState('');
  const [department, setDepartment] = useState('');
  const [timeSlot, setTimeSlot] = useState('');
  const [fillDetails, setFillDetails] = useState(false);
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');

  useEffect(() => {
    const today = new Date().toLocaleDateString('en-GB'); // DD/MM/YYYY
    setDate(today);
  }, []);

  const handleSubmit = async () => {
    if (!drawing?._id) {
      alert("Drawing center data missing");
      return;
    }

    const appointmentData = {
      date,
      particularName,
      department,
      name,
      mobile,
      hospitalId: drawing._id,
           orgName: drawing?.orgName, 
            serviceType: "drawing", 
    };

    try {
      await axios.post('http://localhost:5000/api/appointments', appointmentData);
      alert('Appointment saved successfully!');
      navigate('/');
    } catch (error) {
      console.error('Error saving appointment:', error);
      alert('Failed to save appointment');
    }
  };

  return (
    <Box sx={{ p: 4, backgroundColor: '#faf3dd', minHeight: '100vh' }}>
      <Grid
        container
        spacing={4}
        sx={{
          maxWidth: 800,
          mx: 'auto',
          backgroundColor: 'rgb(138, 204, 173) ',
          borderRadius: 3,
          p: 3,
          boxShadow: 4,
        }}
      >
        {/* Left: Drawing Info */}
        <Grid item xs={12} md={6}>
          <motion.div initial={{ x: -100, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ duration: 0.8 }}>
            <Card sx={{ backgroundColor: '#f0f0f0', borderRadius: 2 }}>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'center', mb: 3 }}>
                  <img
                       src="./drawing1.jpg"
            
                    alt="announcement"
                    height={200}
                    width={300}
                    style={{
                      border: '2px solid black',
                      padding: '20px',
                      borderRadius: '10px',
                      backgroundColor: 'white',
                    }}
                  />
                </Box>

                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                  <Typography variant="h6" fontWeight="bold">Service Details</Typography>
                  <Chip label="Pay Offline" size="small" sx={{ backgroundColor: 'lightgreen', fontWeight: 'bold', height: 24 }} />
                </Box>

                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 2 }}>
                  <img         src={`http://localhost:5000/uploads/${drawing?.profileImage || 'drawing1.jpg'}`} alt="Drawing Logo" style={{ width: 80, height: 80, borderRadius: 8 }} />
                  <Box sx={{ ml: 2 }}>
                    <Typography variant="subtitle1" fontWeight="bold">{drawing?.orgName}</Typography>
                    <Typography variant="body2" color="text.secondary">
                      {drawing?.areaName}, {drawing?.city}
                    </Typography>
                  </Box>
                </Box>

                <Box sx={{ bgcolor: '#d0f0c0', p: 1, borderRadius: 1 }}>
                  <Typography variant="body2" sx={{ fontWeight: 'bold' }}>🛎️ Slots Open</Typography>
                  <Typography variant="body2">{drawing?.openingTime} - {drawing?.closingTime}</Typography>
                </Box>
              </CardContent>
            </Card>
          </motion.div>
        </Grid>

        {/* Right: Booking Form */}
        <Grid item xs={12} md={6}>
          <motion.div initial={{ x: 100, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ duration: 0.8 }}>
            <Card sx={{ borderRadius: 2 }}>
              <CardContent>
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                           <TextField
                                   label="Choose Date"
                                   type="date"
                                   value={date}
                                   onChange={(e) => setDate(e.target.value)}
                                   fullWidth
                                   InputLabelProps={{ shrink: true }}
                                   sx={{ backgroundColor: 'white' }}
                                 />
                  <TextField
                    label="Particular Name *"
                    value={particularName}
                    onChange={(e) => setParticularName(e.target.value)}
                    fullWidth
                    sx={{ backgroundColor: 'white' }}
                  />
                  <TextField
                    label="Departments *"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    fullWidth
                    sx={{ backgroundColor: 'white' }}
                  />
            

                  <FormControlLabel
                    control={<Checkbox checked={fillDetails} onChange={(e) => setFillDetails(e.target.checked)} />}
                    label="Fill my details (Name & Mobile)"
                  />

                  <TextField
                    label="Name *"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    fullWidth
                    sx={{ backgroundColor: 'white' }}
                  />
                        <TextField
                  label="Mobile Number *"
                  value={mobile}
                  onChange={(e) => {
                    const val = e.target.value;
                    if (/^\d{0,10}$/.test(val)) { // ✅ Allow only up to 10 digits
                      setMobile(val);
                    }
                  }}
                  fullWidth
                  sx={{ backgroundColor: 'white' }}
                />

                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 2 }}>
                    <Button variant="contained" sx={{ backgroundColor: '#4b0082' }} onClick={handleSubmit}>
                      Submit
                    </Button>
                 <Button variant="outlined" onClick={() => navigate(-1)}>Cancel</Button>
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </motion.div>
        </Grid>
      </Grid>
    </Box>
  );
};

export default DrawingLogin;
