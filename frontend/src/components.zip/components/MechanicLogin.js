import React, { useState } from 'react';
import {
  Box, Card, CardContent, Typography, TextField, Button,
  Checkbox, FormControlLabel, Chip, Grid
} from '@mui/material';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';

const MechanicLogin = () => {
  const location = useLocation();
  const mechanic = location.state?.mechanic;
  const navigate = useNavigate();

  const [date, setDate] = useState('28/06/2025');
  const [particularName, setParticularName] = useState('');
  const [department, setDepartment] = useState('');
  const [fillDetails, setFillDetails] = useState(false);
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');

  const handleSubmit = async () => {
    const data = {
      date,
      particularName,
      department,
      name,
      mobile,
      hospitalId: mechanic?._id,
      orgName: mechanic?.orgName,
      serviceType: "mechanicshop"
    };

    try {
      await axios.post('http://localhost:5000/api/appointments', data);
      alert("Appointment booked!");
    } catch (err) {
      console.error(err);
      alert("Failed to book.");
    }
  };

  return (
    <Box sx={{ p: 4, backgroundColor: '#fff3e0', minHeight: '100vh' }}>
      <Grid container spacing={3} sx={{
        maxWidth: 730, mx: 'auto', backgroundColor: '#ffe0b2',
        borderRadius: 3, p: 2, boxShadow: 3
      }}>
        {/* Left Info */}
        <Grid item xs={12} sm={6}>
          <Card sx={{ backgroundColor: '#fbe9e7', borderRadius: 2 }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'center', mb: 8 }}>
                <img
                  src="./mech.webp"
                  alt="announcement"
                  style={{
                    border: '2px solid #888', padding: 16, borderRadius: 12,
                    backgroundColor: '#fff', maxWidth: '100%', height: 160
                  }}
                />
              </Box>
              <Typography variant="h6" fontWeight="bold" gutterBottom>
                Mechanic Service Info
              </Typography>
              <Chip label="Pay Offline" size="small" sx={{
                backgroundColor: '#90ee90', fontWeight: 'bold', mb: 2
              }} />
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <img
                  src={`http://localhost:5000/uploads/${mechanic?.profileImage}`}
                  alt="Mechanic Logo"
                  style={{ width: 70, height: 70, borderRadius: 8 }}
                />
                <Box sx={{ ml: 2 }}>
                  <Typography variant="subtitle1" fontWeight="bold">
                    {mechanic?.orgName || 'Mechanic Name'}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {mechanic?.areaName}, {mechanic?.city}
                  </Typography>
                </Box>
              </Box>
              <Box sx={{ backgroundColor: '#ffe0b2', p: 1.5, borderRadius: 2 }}>
                <Typography variant="body2" fontWeight="bold">
                  🛠️ Book your vehicle repair or service now!
                </Typography>
                <Typography variant="body2">
                  {mechanic?.openingTime} - {mechanic?.closingTime}
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Right Form */}
        <Grid item xs={12} sm={6}>
   <Card sx={{ width: '100%', borderRadius: 2, px: 2 }}>

            <CardContent>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <TextField
                  label="Choose Date"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  fullWidth
                  InputLabelProps={{ shrink: true }}
                  sx={{ backgroundColor: 'white' }}
                />
                <TextField
                  label="Vehicle / Issue *"
                  value={particularName}
                  onChange={(e) => setParticularName(e.target.value)}
                  fullWidth
                  sx={{ backgroundColor: 'white' }}
                />
                <TextField
                  label="Service Type (Repair/Oil/Checkup)"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  fullWidth
                  sx={{ backgroundColor: 'white' }}
                />
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={fillDetails}
                      onChange={(e) => setFillDetails(e.target.checked)}
                    />
                  }
                  label="Fill my details"
                />
                <TextField
                  label="Name *"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  fullWidth
                  sx={{ backgroundColor: 'white' }}
                />
                <TextField
                  label="Mobile Number *"
                  value={mobile}
                  onChange={(e) => {
                    const val = e.target.value;
                    if (/^\d{0,10}$/.test(val)) setMobile(val);
                  }}
                  fullWidth
                  sx={{ backgroundColor: 'white' }}
                />
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 2 }}>
                  <Button variant="contained" sx={{ backgroundColor: '#ff7043' }} onClick={handleSubmit}>
                    Submit
                  </Button>
                  <Button variant="outlined" onClick={() => navigate(-1)}>
                    Cancel
                  </Button>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default MechanicLogin;
