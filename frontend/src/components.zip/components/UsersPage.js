// src/pages/UsersPage.js
import React, { useEffect, useState } from 'react';
import { Container, Typography, Box } from '@mui/material';
import { getUsers } from '../api';
import DataTable from '../components/DataTable';

const UsersPage = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const loadUsers = async () => {
      try {
        const { data } = await getUsers();
        setUsers(data.users);
      } catch (err) {
        console.error('Failed to load users:', err);
      }
    };

    loadUsers();
  }, []);

  return (
    <Container maxWidth="md" sx={{ mt: 8 }}>
      <Typography variant="h4" align="center" gutterBottom>
        Registered Users
      </Typography>

      <Box mt={3}>
        <DataTable rows={users} />
      </Box>
    </Container>
  );
};

export default UsersPage;