import React, { useState } from 'react';
import {
  Container, Paper, Typography, Grid,
  TextField, Button, Box
} from '@mui/material';
import { registerUser } from '../api';
import { useNavigate } from 'react-router-dom';

const emptyForm = {
  username: '',
  email: '',
  password: '',
  confirmPassword: ''
};

export default function AdminPage() {
  const [form, setForm] = useState(emptyForm);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { data } = await registerUser(form);
      alert(data.message || 'Registration successful');
      setForm(emptyForm);
      navigate('/users');
    } catch (err) {
      alert(err.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <Container maxWidth="sm" sx={{ mt: 8 }}>
      <Paper
        elevation={6}
        sx={{
          p: 4,
          borderRadius: 4,
          bgcolor: '#fdf6fd',
          boxShadow: '0px 4px 20px rgba(206, 153, 202, 0.4)',
          fontFamily: 'Michroma, sans-serif',
        }}
      >
        <Typography
          variant="h4"
          align="center"
          gutterBottom
          sx={{
            fontWeight: 'bold',
            color: '#4b004b',
            backgroundColor: '#ce99ca',
            py: 2,
            borderRadius: 2,
            mb: 3,
            fontFamily: 'Michroma, sans-serif'
          }}
        >
          ✨ Bookify Admin ✨
        </Typography>

        <Box
          component="form"
          onSubmit={handleSubmit}
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
          }}
        >
          <Grid container spacing={2} justifyContent="center">
            {['username', 'email', 'password', 'confirmPassword'].map((field) => (
              <Grid item xs={12} key={field}>
                <Box sx={{ textAlign: 'center' }}>
                  <TextField
                    label={field.replace(/^\w/, (c) => c.toUpperCase())}
                    name={field}
                    type={field.includes('password') ? 'password' : 'text'}
                    value={form[field]}
                    onChange={handleChange}
                    fullWidth
                    size="small"
                    required
                    sx={{
                      fontFamily: 'Michroma, sans-serif',
                      '& label': { fontFamily: 'Michroma, sans-serif', textAlign: 'center' },
                      '& input': { fontFamily: 'Michroma, sans-serif', textAlign: 'center' },
                      '& label.Mui-focused': { color: '#ce99ca' },
                      '& .MuiInput-underline:after': { borderBottomColor: '#ce99ca' },
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': { borderColor: '#ce99ca' },
                        '&:hover fieldset': { borderColor: '#c078b4' },
                        '&.Mui-focused fieldset': { borderColor: '#ce99ca' },
                      },
                    }}
                  />
                </Box>
              </Grid>
            ))}
          </Grid>

          <Box sx={{ mt: 4, textAlign: 'center' }}>
            <Button
              type="submit"
              variant="contained"
              sx={{
                backgroundColor: '#ce99ca',
                '&:hover': { backgroundColor: '#c078b4' },
                color: 'white',
                fontWeight: 'bold',
                px: 5,
                fontFamily: 'Michroma, sans-serif'
              }}
            >
              Register
            </Button>
          </Box>
        </Box>
      </Paper>
    </Container>
  );
}
